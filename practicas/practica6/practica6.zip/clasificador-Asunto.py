# -*- coding: utf-8 -*-<

import glob
import re
import random
from NaiveBayes import *
from Split import *
from collections import Counter     

data = []

path = r"/home/sleir/Documents/UNDAV-9no-cuat/Sistemas-de-Gestión-de-Bases-de-Datos/Programas-Practicas/practica6/Spam/*/*.*"
data = []
for fn in glob.glob(path):
    is_spam = "ham" not in fn
    with open(fn,'r') as file:
    	for line in file:
           if line.startswith("Subject:"):
                subject = re.sub(r"^Subject: ", "", line)
                data.append((subject, is_spam))


random.seed(0)
train_data, test_data = split_data(data, 0.75)
classifier = NaiveBayes()
classifier.train(train_data)

# triplets (subject, actual is_spam, predicted spam probability)
classified = [(subject, is_spam, classifier.classify(subject))
              for subject, is_spam in test_data]

# assume that spam_probability > 0.5 corresponds to spam prediction
# and count the combinations of (actual is_spam, predicted is_spam)
counts = Counter((is_spam, spam_probability > 0.5)
                 for _, is_spam, spam_probability in classified)

print counts
